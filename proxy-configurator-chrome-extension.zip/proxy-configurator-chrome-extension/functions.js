async function onProxy() {
    try {
        const data = await chrome.storage.local.get(['proxySetting', 'proxyMode', 'domainList']);
        const proxySetting = JSON.parse(data.proxySetting || '{}');
        const proxyMode = data.proxyMode || 'proxyAll';
        const domainList = (data.domainList || '').split('\n')
            .map(d => d.trim().toLowerCase())
            .filter(Boolean);

        const proxy = {
            type: 'http',
            host: proxySetting.http_host,
            port: proxySetting.http_port
        };

        const proxyString = `PROXY ${proxy.host}:${proxy.port}`;
        const config = { mode: 'pac_script', pacScript: {} };

        if (proxyMode === 'proxyAll') {
            config.pacScript.data = `
                function FindProxyForURL(url, host) {
                    return "${proxyString}";
                }
            `;
        } else if (proxyMode === 'proxyOnly') {
            const sitesArray = JSON.stringify(domainList);
            config.pacScript.data = `
                function FindProxyForURL(url, host) {
                    host = host.toLowerCase();
                    var sites = ${sitesArray};
                    for (var i = 0; i < sites.length; i++) {
                        if (dnsDomainIs(host, sites[i])) return "${proxyString}";
                    }
                    return "DIRECT";
                }
            `;
        } else if (proxyMode === 'proxyExcept') {
            const sitesArray = JSON.stringify(domainList);
            config.pacScript.data = `
                function FindProxyForURL(url, host) {
                    host = host.toLowerCase();
                    var sites = ${sitesArray};
                    for (var i = 0; i < sites.length; i++) {
                        if (dnsDomainIs(host, sites[i])) return "DIRECT";
                    }
                    return "${proxyString}";
                }
            `;
        }

        await chrome.proxy.settings.set({ value: config, scope: 'regular' });
        showNotification(true);
        return proxy;
    } catch (error) {
        console.error('Error in onProxy:', error);
    }
}

function offProxy() {
    chrome.proxy.settings.set({
        value: { mode: 'direct' },
        scope: 'regular'
    }, () => {
        showNotification(false);
    });
}

async function setIcon(str) {
    const path = str === 'off' ? 'icons/off.png' : 'icons/on.png';
    await chrome.action.setIcon({ path });
}

function showNotification(isEnabled) {
    chrome.storage.local.get('proxySetting', (data) => {
        let setting = {};
        try {
            setting = JSON.parse(data.proxySetting || '{}');
        } catch (e) {}
        const title = isEnabled ? 'VPN Connected' : 'VPN Disconnected';
        const message = isEnabled
            ? `Connected to: ${setting.http_host || 'Unknown'}:${setting.http_port || 'Unknown'}`
            : 'VPN is now disabled';

        chrome.notifications.create({
            type: 'basic',
            iconUrl: `icons/${isEnabled ? 'on' : 'off'}.png`,
            title,
            message
        });
    });
}