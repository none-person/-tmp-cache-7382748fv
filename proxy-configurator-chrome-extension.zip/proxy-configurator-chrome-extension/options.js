    document.querySelector('#proxyList').value = data.proxyList || '';

    async function determineProxyType(proxyStr) {
        if (proxyStr.toLowerCase().startsWith('socks5:')) return 'SOCKS5';
        if (proxyStr.toLowerCase().startsWith('socks4:')) return 'SOCKS4';
        if (proxyStr.toLowerCase().startsWith('http:') || proxyStr.toLowerCase().startsWith('https:')) return 'HTTPS';
        const [host, port] = proxyStr.split(':');
        const portNum = parseInt(port);
        if ([1080, 1081, 1085, 9050, 9051].includes(portNum)) return 'SOCKS5';
        if ([3128, 8080, 8081, 80, 8000].includes(portNum)) return 'HTTPS';
        return 'HTTPS';
    }

    function showStatusBadge(button, message, type = 'success') {
        const badge = document.createElement('span');
        badge.className = `status-badge ${type}`;
        badge.textContent = message;
        button.parentNode.appendChild(badge);
        setTimeout(() => badge.remove(), 3000);
    }

    function getCountryFlag(countryCode) {
        if (!countryCode || countryCode.length !== 2) return '';
        return String.fromCodePoint(...[...countryCode.toUpperCase()].map(c => 127397 + c.charCodeAt(0)));
    }

    async function getProxyCountryInfo(ip) {
        try {
            const response = await fetch(`https://ip2c.org/${ip}`);
            const data = await response.text();
            const [status, countryCode] = data.split(';');
            if (status === '1') return { code: countryCode, flag: getCountryFlag(countryCode) };
            return { code: 'Unknown', flag: '' };
        } catch (error) {
            console.error('Error fetching country:', error);
            return { code: 'Unknown', flag: '' };
        }
    }

    document.getElementById('importUaList').addEventListener('click', async () => {
        const button = document.getElementById('importUaList');
        button.disabled = true;
        try {
            const response = await fetch('https://seojacky.github.io/pages/ua-blacklist-domen.txt');
            const text = await response.text();
            const domains = text.split('\n').map(d => d.trim()).filter(Boolean);
            document.getElementById('domainList').value = domains.join('\n');
            showStatusBadge(button, `Imported ${domains  .length} domains`);
        } catch (error) {
            showStatusBadge(button, 'Failed', 'error');
        } finally {
            button.disabled = false;
        }
    });

    document.getElementById('importRuList').addEventListener('click', async () => {
        const button = document.getElementById('importRuList');
        button.disabled = true;
        try {
            const response = await fetch('https://raw.githubusercontent.com/itdoginfo/allow-domains/main/Russia/outside-raw.lst');
            const text = await response.text();
            const domains = text.split('\n').map(d => d.trim()).filter(Boolean);
            document.getElementById('domainList').value = domains.join('\n');
            showStatusBadge(button, `Imported ${domains.length} domains`);
        } catch (error) {
            showStatusBadge(button, 'Failed', 'error');
        } finally {
            button.disabled = false;
        }
    });

    document.getElementById('importProxyProwler').addEventListener('click', async () => {
        const button = document.getElementById('importProxyProwler');
        button.disabled = true;
        button.textContent = 'Importing...';

        try {
            const lastImport = await chrome.storage.local.get('lastProxyProwlerImport');
            const now = Date.now();
            if (lastImport.lastProxyProwlerImport && (now - lastImport.lastProxyProwlerImport < 3600000)) {
                showStatusBadge(button, 'Cached (1h cooldown)', 'success');
                return;
            }

            const files = [
                { name: 'SOCKS5.txt', type: 'socks5' },
                { name: 'SOCKS4.txt', type: 'socks4' },
                { name: 'HTTPS.txt', type: 'https' }
            ];

            let allProxies = [];
            for (const file of files) {
                try {
                    const response = await fetch(`https://raw.githubusercontent.com/Argh94/ProxyProwler/main/proxy_output/${file.name}`);
                    if (!response.ok) continue;
                    const text = await response.text();
                    const proxies = text.split('\n')
                        .map(line => line.trim())
                        .filter(Boolean)
                        .map(p => `${file.type}:${p}`);
                    allProxies = allProxies.concat(proxies);
                } catch (e) { console.error(`Failed ${file.name}:`, e); }
            }

            if (allProxies.length === 0) throw new Error('No proxies');

            const proxyInfoList = await Promise.all(allProxies.map(async (proxyStr) => {
                const parts = proxyStr.split(':');
                const host = parts[1];
                const [countryInfo, proxyType] = await Promise.all([
                    getProxyCountryInfo(host),
                    determineProxyType(proxyStr)
                ]);
                return { proxy: proxyStr, countryInfo, type: proxyType };
            }));

            await chrome.storage.local.set({
                proxyList: allProxies.join('\n'),
                proxyInfoList: JSON.stringify(proxyInfoList),
                lastProxyProwlerImport: now
            });

            document.getElementById('proxyList').value = allProxies.join('\n');
            showStatusBadge(button, `Imported ${allProxies.length} proxies`, 'success');
        } catch (error) {
            showStatusBadge(button, 'Failed: ' + error.message, 'error');
        } finally {
            button.disabled = false;
            button.textContent = 'Import from ProxyProwler';
        }
    });

    document.getElementById('importDomainList').addEventListener('click', () => {
        const input = document.createElement('input');
        input.type = 'file';
        input.accept = '.txt';
        input.onchange = e => {
            const file = e.target.files[0];
            if (!file) return;
            const reader = new FileReader();
            reader.onload = evmnt => {
                const domains = evmnt.target.result.split('\n').map(d => d.trim()).filter(Boolean);
                document.getElementById('domainList').value = domains.join('\n');
                showStatusBadge(document.getElementById('importDomainList'), `Imported ${domains.length} domains`);
            };
            reader.readAsText(file);
        };
        input.click();
    });

    document.getElementById('exportDomainList').addEventListener('click', () => {
        const domains = document.getElementById('domainList').value;
        if (!domains.trim()) {
            showStatusBadge(document.getElementById('exportDomainList'), 'Empty', 'error');
            return;
        }
        const blob = new Blob([domains], { type: 'text/plain' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'domains.txt';
        a.click();
        URL.revokeObjectURL(url);
        showStatusBadge(document.getElementById('exportDomainList'), 'Exported');
    });

    document.getElementById('saveSettings').addEventListener('click', async function() {
        const button = this;
        button.disabled = true;
        button.textContent = 'Saving...';
        try {
            const mode = document.querySelector('input[name="proxyMode"]:checked').value;
            const domains = document.querySelector('#domainList').value.trim();
            const proxies = document.querySelector('#proxyList').value.trim();

            const proxyLines = proxies.split('\n').filter(l => l.trim());
            const valid = proxyLines.every(l => {
                const p = l.split(':');
                return p.length === 2 || p.length === 3 || p.length === 4;
            });
            if (!valid) { alert('Invalid proxy format'); return; }

            const proxyInfoList = await Promise.all(proxyLines.map(async (p) => {
                const parts = p.split(':');
                const host = parts.length >= 3 ? parts[1] : parts[0];
                const [ci, pt] = await Promise.all([getProxyCountryInfo(host), determineProxyType(p)]);
                return { proxy: p, countryInfo: ci, type: pt };
            }));

            await chrome.storage.local.set({
                proxyMode: mode,
                domainList: domains,
                proxyList: proxies,
                proxyInfoList: JSON.stringify(proxyInfoList)
            });

            if (proxyLines.length > 0) {
                const first = proxyLines[0].split(':');
                const [host, port] = first.length >= 3 ? first.slice(1, 3) : first;
                const setting = { type: proxyInfoList[0].type, http_host: host, http_port: port, auth: { enable: false } };
                await chrome.storage.local.set({ proxySetting: JSON.stringify(setting) });
            }

            chrome.proxy.settings.get({ incognito: false }, (c) => {
                if (c.value?.mode === 'pac_script') onProxy();
            });

            showStatusBadge(button, 'Saved!');
        } catch (e) {
            showStatusBadge(button, 'Error', 'error');
        } finally {
            button.disabled = false;
            button.textContent = 'Save Settings';
        }
    });

    document.querySelectorAll('input[name="proxyMode"]').forEach(r => {
        r.addEventListener('change', function() {
            const ta = document.querySelector('#domainList');
            ta.disabled = this.value === 'proxyAll';
            ta.style.opacity = this.value === 'proxyAll' ? '0.5' : '1';
        });
    });
    const initMode = document.querySelector('input[name="proxyMode"]:checked').value;
    const ta = document.querySelector('#domainList');
    if (initMode === 'proxyAll') { ta.disabled = true; ta.style.opacity = '0.5'; }
});