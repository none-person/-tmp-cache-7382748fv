
chrome.proxy.onProxyError.addListener((details) => {
    console.error('Proxy error:', details);
    updateIcon(false).catch(err => console.error('updateIcon failed:', err));
});

async function updateIcon(isEnabled, isSiteUsingProxy = false) {
    try {
        const data = await getStorageData(['proxyMode']);
        const proxyMode = data.proxyMode || 'proxyAll';

        if (!isEnabled) {
            chrome.action.setIcon({ path: 'icons/off.png' });
            chrome.action.setBadgeText({ text: '' });
            return;
        }

        chrome.action.setIcon({ path: 'icons/on.png' });

        const showBadge = (proxyMode === 'proxyOnly' || proxyMode === 'proxyExcept') && isSiteUsingProxy;
        chrome.action.setBadgeText({ text: showBadge ? 'ON' : '' });

        if (showBadge) {
            chrome.action.setBadgeBackgroundColor({ color: '#4ade80' });
            chrome.action.setBadgeTextColor({ color: '#ffffff' });
        }
    } catch (error) {
        console.error('Error updating icon:', error);
    }
}

function getStorageData(keys) {
    return new Promise((resolve) => {
        chrome.storage.local.get(keys, (data) => {
            resolve(data);
        });
    });
}

async function checkIfSiteUsesVPN(tabId, url) {
    if (!url || !/^https?:\/\//i.test(url)) return;

    try {
        const data = await getStorageData(['proxyMode', 'domainList']);
        const config = await new Promise((resolve) => {
            chrome.proxy.settings.get({ incognito: false }, resolve);
        });

        const proxyMode = data.proxyMode || 'proxyAll';
        const domainList = (data.domainList || '')
            .split('\n')
            .map(d => d.trim().toLowerCase())
            .filter(Boolean);

        const isEnabled = config.value?.mode === 'pac_script';

        if (!isEnabled) {
            await updateIcon(false);
            return;
        }

        const hostname = new URL(url).hostname.toLowerCase();
        const isInList = domainList.some(domain =>
            hostname === domain || hostname.endsWith('.' + domain)
        );

        let showBadge = false;
        if (proxyMode === 'proxyOnly') showBadge = isInList;
        else if (proxyMode === 'proxyExcept') showBadge = !isInList;
        else showBadge = true;

        await updateIcon(true, showBadge);
    } catch (error) {
        console.error('Error in checkIfSiteUsesVPN:', error);
        await updateIcon(true, false);
    }
}

chrome.tabs.onActivated.addListener(async (activeInfo) => {
    try {
        const tab = await chrome.tabs.get(activeInfo.tabId);
        if (tab?.url) await checkIfSiteUsesVPN(activeInfo.tabId, tab.url);
    } catch (e) {}
});

chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
    if ((changeInfo.url || changeInfo.status === 'complete') && tab?.url) {
        await checkIfSiteUsesVPN(tabId, tab.url);
    }
});

chrome.webRequest.onAuthRequired.addListener(
    (details, callbackFn) => {
        getStorageData(['proxySetting']).then((data) => {
            let setting = {};
            try {
                setting = JSON.parse(data.proxySetting || '{}');
            } catch (e) {
                console.error('Invalid proxySetting:', e);
            }

            const hasAuth = setting.auth?.enable && setting.auth?.user && setting.auth?.pass;

            if (typeof callbackFn === 'function') {
                if (hasAuth) {
                    callbackFn({
                        authCredentials: {
                            username: setting.auth.user,
                            password: setting.auth.pass
                        }
                    });
                } else {
                    callbackFn({});
                }
            }
        });
    },
    { urls: ['<all_urls>'] },
    ['blocking']
);