document.addEventListener('DOMContentLoaded', async function () {
    const proxyType = document.getElementById('proxyType');
    const proxyHost = document.getElementById('proxyHost');
    const proxyPort = document.getElementById('proxyPort');
    const proxyUser = document.getElementById('proxyUser');
    const proxyPass = document.getElementById('proxyPass');
    const powerBtn = document.getElementById('powerBtn');
    const statusText = document.getElementById('statusText');

    const data = await chrome.storage.local.get(['proxySetting']);
    let setting = {};
    try {
        setting = JSON.parse(data.proxySetting || '{}');
    } catch (e) {}
    if (setting.http_host) {
        proxyType.value = setting.type || 'http';
        proxyHost.value = setting.http_host || '';
        proxyPort.value = setting.http_port || '';
        proxyUser.value = setting.auth?.user || '';
        proxyPass.value = setting.auth?.pass || '';
    }

    chrome.proxy.settings.get({ incognito: false }, (config) => {
        const enabled = config.value?.mode === 'pac_script';
        updateUI(enabled);
    });

    powerBtn.addEventListener('click', async () => {
        const isOn = powerBtn.classList.contains('on');

        if (isOn) {
            offProxy();
            updateUI(false);
            showNotification(false);
        } else {
            const host = proxyHost.value.trim();
            const port = proxyPort.value.trim();
            const user = proxyUser.value.trim();
            const pass = proxyPass.value.trim();

            if (!host || !port) {
                alert('Please enter host and port');
                return;
            }

            const setting = {
                type: proxyType.value,
                http_host: host,
                http_port: port,
                auth: {
                    enable: !!user && !!pass,
                    user: user,
                    pass: pass
                }
            };

            await chrome.storage.local.set({
                proxySetting: JSON.stringify(setting)
            });

            try {
                await onProxy();
                updateUI(true);
                showNotification(true);
            } catch (e) {
                console.error('Connection failed:', e);
                alert('Failed to connect. Check host/port/username/password.');
                updateUI(false);
            }
        }
    });

    function updateUI(enabled) {
        if (enabled) {
            powerBtn.classList.remove('off');
            powerBtn.classList.add('on');
            statusText.classList.remove('off');
            statusText.classList.add('on');
            statusText.innerHTML = '<span class="status-dot"></span> Connected';
        } else {
            powerBtn.classList.remove('on');
            powerBtn.classList.add('off');
            statusText.classList.remove('on');
            statusText.classList.add('off');
            statusText.innerHTML = '<span class="status-dot"></span> Disconnected';
        }
    }
});